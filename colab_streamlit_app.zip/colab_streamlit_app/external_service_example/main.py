from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="External Automation Service Example")


class BarcodePayload(BaseModel):
    code: str


@app.get("/health")
def health() -> dict:
    return {"ok": True}


@app.post("/barcode")
def barcode(payload: BarcodePayload) -> dict:
    # Replace this with your automation, SEFAZ integration, etc.
    return {"received": payload.code, "status": "processed"}

