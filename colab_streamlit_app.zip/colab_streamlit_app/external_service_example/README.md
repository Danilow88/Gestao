## External Service Example (FastAPI)

Local run:

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8080 --reload
```

Endpoints:
- GET /health
- POST /barcode { code: string }

Deploy to your preferred platform (Render, Railway, Fly.io, Cloud Run) and set the env var in Colab:

```
EXTERNAL_SERVICE_BASE_URL=https://<your-deployed-service>
```

