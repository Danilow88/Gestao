#!/usr/bin/env bash
set -euo pipefail

# Usage:
#   export GH_USER="your-username"
#   export GH_TOKEN="ghp_xxx"  # classic PAT with repo scope
#   export GH_REPO_NAME="colab-streamlit-app"
#   ./scripts/create_and_push_repo.sh

if [[ -z "${GH_USER:-}" || -z "${GH_TOKEN:-}" || -z "${GH_REPO_NAME:-}" ]]; then
  echo "Missing GH_USER, GH_TOKEN or GH_REPO_NAME env vars" >&2
  exit 1
fi

API="https://api.github.com/user/repos"

echo "Creating repo ${GH_REPO_NAME} under ${GH_USER}..."
curl -s -H "Authorization: token ${GH_TOKEN}" \
     -H "Accept: application/vnd.github+json" \
     ${API} \
     -d "{\"name\":\"${GH_REPO_NAME}\",\"private\":false}" >/dev/null

git init -q || true
git add .
git commit -m "feat: initial colab-optimized app" >/dev/null 2>&1 || true
git branch -M main || true
git remote remove origin >/dev/null 2>&1 || true
git remote add origin https://github.com/${GH_USER}/${GH_REPO_NAME}.git

echo "Pushing to GitHub..."
git push -u origin main
echo "Done: https://github.com/${GH_USER}/${GH_REPO_NAME}"

