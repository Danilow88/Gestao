import os
import io
import base64
from typing import Optional

import streamlit as st
import pandas as pd
import plotly.express as px
from .external_service_client import ExternalServiceClient

COLAB_MODE = os.environ.get("COLAB", "0") == "1"


def load_data(uploaded_file: Optional[io.BytesIO]) -> pd.DataFrame:
    if uploaded_file is None:
        return pd.DataFrame()
    try:
        if uploaded_file.name.endswith('.csv'):
            return pd.read_csv(uploaded_file)
        if uploaded_file.name.endswith('.xlsx'):
            return pd.read_excel(uploaded_file)
    except Exception as exc:
        st.error(f"Erro ao carregar arquivo: {exc}")
    return pd.DataFrame()


def render_scanner_component() -> None:
    st.markdown("### Leitor de Código de Barras/QR (lado do cliente)")
    st.caption(
        "A captura é feita no navegador via QuaggaJS. Em Colab, o app roda em um iframe; autorize a câmera."
    )

    scanner_html = """
    <style>
      .scanner-wrap { display: flex; flex-direction: column; gap: 8px; }
      video { width: 100%; border-radius: 8px; }
      #result { font-family: sans-serif; font-size: 14px; }
      button { padding: 8px 12px; border-radius: 6px; border: 1px solid #999; }
    </style>
    <div class="scanner-wrap">
      <div id="result">Aguardando leitura...</div>
      <video id="preview" playsinline></video>
      <div style="display:flex; gap:8px;">
        <button id="start">Iniciar</button>
        <button id="stop">Parar</button>
      </div>
    </div>
    <script src="https://unpkg.com/@ericblade/quagga2/dist/quagga.js"></script>
    <script>
    (function(){
      const result = document.getElementById('result');
      const startBtn = document.getElementById('start');
      const stopBtn = document.getElementById('stop');
      const preview = document.getElementById('preview');

      function startScanner(){
        Quagga.init({
          inputStream: {
            type: "LiveStream",
            constraints: {
              facingMode: "environment",
            },
            target: preview
          },
          decoder: { readers: [
            "ean_reader","ean_8_reader","code_128_reader",
            "upc_reader","upc_e_reader","code_39_reader",
            "qr_reader"
          ]}
        }, function(err) {
          if (err) { result.innerText = 'Erro: ' + err; return }
          Quagga.start();
          result.innerText = 'Escaneando...'
        });

        Quagga.onDetected(function(d){
          const code = d && d.codeResult && d.codeResult.code;
          if (code){
            result.innerText = 'Lido: ' + code;
            // Comunica ao Streamlit via hash para leitura no Python
            const newHash = '#barcode=' + encodeURIComponent(code);
            if (window.location.hash !== newHash){
              window.location.hash = newHash;
            }
            Quagga.stop();
          }
        });
      }

      function stopScanner(){ try { Quagga.stop(); result.innerText = 'Parado'; } catch(e){} }

      startBtn.addEventListener('click', startScanner);
      stopBtn.addEventListener('click', stopScanner);
    })();
    </script>
    """
    st.components.v1.html(scanner_html, height=420)

    # Lê o hash para recuperar o código; funciona porque Colab expõe a URL final
    barcode_value = st.experimental_get_query_params().get("barcode", [""])[0]
    if barcode_value:
        st.success(f"Código detectado: {barcode_value}")
        st.session_state["last_barcode"] = barcode_value


def render_upload_decode() -> None:
    st.markdown("### Fallback: Upload de imagem para leitura do código")
    uploaded = st.file_uploader("Envie uma imagem contendo o código de barras/QR", type=["png","jpg","jpeg"])
    if uploaded is not None:
        try:
            import PIL.Image
            from pyzbar.pyzbar import decode as zbar_decode
            image = PIL.Image.open(uploaded)
            codes = zbar_decode(image)
            if codes:
                code = codes[0].data.decode('utf-8', errors='ignore')
                st.success(f"Código detectado: {code}")
                st.session_state["last_barcode"] = code
            else:
                st.warning("Nenhum código detectado na imagem.")
        except Exception as exc:
            st.error(f"Falha ao decodificar: {exc}")


def render_manual_entry() -> None:
    st.markdown("### Fallback: Digitação manual")
    value = st.text_input("Digite o código manualmente:")
    if st.button("Usar código"):
        if value:
            st.session_state["last_barcode"] = value
            st.success(f"Código definido: {value}")
        else:
            st.warning("Informe um valor.")


def main():
    st.set_page_config(page_title="Colab Streamlit App", layout="wide")
    st.title("Colab Streamlit App")
    st.caption("Modo Colab: {}".format("Ativo" if COLAB_MODE else "Desativado"))

    with st.sidebar:
        st.header("Config")
        st.write("- Recursos pesados e integrações locais ficam desativados no Colab.")
        st.write("- Use os fallbacks abaixo para scanner e dados.")

        uploaded = st.file_uploader("Carregar base CSV/XLSX", type=["csv","xlsx"], key="datafile")
        df = load_data(uploaded)
        if not df.empty:
            st.session_state["dataframe"] = df
            st.success(f"Dados carregados: {df.shape[0]} linhas, {df.shape[1]} colunas")

    tabs = st.tabs(["Dashboard", "Scanner", "Ajuda"])

    with tabs[0]:
        df = st.session_state.get("dataframe")
        if df is None or df.empty:
            st.info("Envie um CSV/XLSX na barra lateral para visualizar o dashboard.")
        else:
            st.subheader("Visão geral")
            st.dataframe(df.head(50))
            numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
            if len(numeric_cols) >= 2:
                xcol = st.selectbox("Eixo X", options=numeric_cols, index=0)
                ycol = st.selectbox("Eixo Y", options=numeric_cols, index=min(1, len(numeric_cols)-1))
                fig = px.scatter(df, x=xcol, y=ycol, title=f"{xcol} vs {ycol}")
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("Apenas colunas numéricas são usadas no gráfico.")

    with tabs[1]:
        st.write("Último código lido:", st.session_state.get("last_barcode", "—"))
        render_scanner_component()
        st.divider()
        render_upload_decode()
        st.divider()
        render_manual_entry()
        st.divider()
        st.subheader("Enviar para serviço externo (opcional)")
        svc = ExternalServiceClient()
        col_a, col_b = st.columns([1, 2])
        with col_a:
            st.write("Configured:", svc.is_configured())
        with col_b:
            if st.button("Testar /health"):
                st.json(svc.health())
        code_to_send = st.session_state.get("last_barcode")
        disabled = not bool(code_to_send)
        if st.button("Enviar último código", disabled=disabled):
            if not code_to_send:
                st.warning("Nenhum código disponível.")
            else:
                st.json(svc.submit_barcode(code_to_send))

    with tabs[2]:
        st.markdown("""
        - Em Colab, a aplicação é servida em um túnel (ngrok). A câmera fica sob controle do navegador.
        - O scanner roda no cliente (QuaggaJS). Para QR e 1D comuns, a taxa de leitura é boa.
        - Integrações que requerem drivers/certificados/serviços locais devem ser chamadas via API externa.
        """)


if __name__ == "__main__":
    main()

