import os
from typing import Any, Dict, Optional

import requests


class ExternalServiceClient:
    """Client for calling automation/integration services outside Colab.

    Configure base URL with ENV var EXTERNAL_SERVICE_BASE_URL, e.g.:
        https://your-service.example.com
    """

    def __init__(self, base_url: Optional[str] = None, timeout_seconds: int = 30) -> None:
        self.base_url = base_url or os.environ.get("EXTERNAL_SERVICE_BASE_URL", "")
        self.timeout_seconds = timeout_seconds

    def is_configured(self) -> bool:
        return bool(self.base_url)

    def health(self) -> Dict[str, Any]:
        if not self.is_configured():
            return {"ok": False, "error": "EXTERNAL_SERVICE_BASE_URL not set"}
        try:
            resp = requests.get(f"{self.base_url}/health", timeout=self.timeout_seconds)
            return {"ok": resp.ok, "status_code": resp.status_code, "body": resp.text}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def submit_barcode(self, code: str) -> Dict[str, Any]:
        if not self.is_configured():
            return {"ok": False, "error": "EXTERNAL_SERVICE_BASE_URL not set"}
        try:
            resp = requests.post(
                f"{self.base_url}/barcode",
                json={"code": code},
                timeout=self.timeout_seconds,
            )
            data: Dict[str, Any]
            try:
                data = resp.json()
            except Exception:
                data = {"raw": resp.text}
            return {"ok": resp.ok, "status_code": resp.status_code, "data": data}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

