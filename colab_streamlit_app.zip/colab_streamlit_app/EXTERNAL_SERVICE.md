## External Automation Service (Optional)

Colab impõe limitações para drivers, certificados e serviços long-running. Para integrações (ex.: SEFAZ, automações com navegador), rode um microserviço fora do Colab e chame-o via HTTP.

### Protocolo sugerido

- `GET /health` → healthcheck
- `POST /barcode { code: string }` → processa código de barras/QR
- Outros endpoints conforme sua automação

Configure a URL base via env var `EXTERNAL_SERVICE_BASE_URL`.

### Exemplo rápido (FastAPI)

```python
from fastapi import FastAPI

app = FastAPI()

@app.get('/health')
def health():
    return {"ok": True}

@app.post('/barcode')
def barcode(payload: dict):
    code = payload.get('code')
    # faça o processamento/consulta externa aqui
    return {"received": code, "status": "processed"}
```

Hospede em Cloud Run/Render/Railway/Fly.io/VPS. Em Colab, o app chamará esse serviço.

